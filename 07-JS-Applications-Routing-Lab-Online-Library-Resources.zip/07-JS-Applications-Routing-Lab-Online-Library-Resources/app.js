// Import utilities
import { renderToMain, attachEventListener } from './utils/renderHelper.js';
import { getFormData } from './utils/formHelper.js';

// Import data layer
import { getAllBooks, getBookById, addBook } from './books.js';

// Import view templates
import { homeTemplate } from './views/homeView.js';
import { booksListTemplate } from './views/booksView.js';
import { bookDetailsTemplate } from './views/bookDetailsView.js';
import { addBookFormTemplate, successMessageTemplate } from './views/addBookView.js';


function showHome() {
    renderToMain(homeTemplate());
}

function showBooks() {
    const books = getAllBooks();
    renderToMain(booksListTemplate(books));
}

function showBookDetails(ctx) {
    const id = Number(ctx.params.id);
    const book = getBookById(id);
    renderToMain(bookDetailsTemplate(book));
}

function showAddBookForm() {
    renderToMain(addBookFormTemplate());
    attachEventListener('addBookForm', 'submit', handleBookSubmit);
}


// Event handler for form submit
function handleBookSubmit(e) {
    e.preventDefault();
    const formData = getFormData(e.target);
    const newBook = addBook(formData);
    renderToMain(successMessageTemplate(newBook.title));
    setTimeout(() => page('/books'), 2000);
}

// Define route for home page
page("/", showHome);

// Define route for books list
page("/books", showBooks);

// Define route for adding a book
page('/books/add', showAddBookForm);

// Define route for book details (with parameter!)
page("/books/:id", showBookDetails);

// Start the Page.js router
page();