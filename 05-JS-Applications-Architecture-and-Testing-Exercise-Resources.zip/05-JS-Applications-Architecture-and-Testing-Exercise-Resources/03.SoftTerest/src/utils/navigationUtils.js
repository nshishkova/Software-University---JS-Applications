import { userUtils } from "./userUtils.js";

export function updateNav() {
    const hasUser = userUtils.hasUser();
    const userNav = document.querySelectorAll("a[data-nav='user']");
    const guest = document.querySelectorAll("a[data-nav='guest']");
    if(hasUser) {
        userNav.forEach(a => a.style.display = "block");
        guest.forEach(a => a.style.display = "none");
    } else {
        userNav.forEach(a => a.style.display = "none");
        guest.forEach(a => a.style.display = "block");
    }
}